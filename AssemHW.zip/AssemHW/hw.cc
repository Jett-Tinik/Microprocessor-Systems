/*
identify what is in each register


 .global main
main:

0x555550750:	mov x0, #3                      move 3 into x0 x0=3;
0x555550754:	mov x1, #4                      move 4 into x1 x1=4
0x555550758:	stp lr, x0,[sp, #-16]!          writes the link register and x0
                                             into a particular stack
0x55555075C:	bl  f  (0x555550764)            jump foward to 0x555550764
0x555550760:  ldr lr, x0, [sp], #16           reload lr and x0
                                             (what was stored in 0x555550758 )
0x555550764:	ret                             go back (0x555550760),
                                             second time through ret, exits out
                                             of func
0x555550768:	add  x0, x0, x1 // lr=________  will not run because we
                                            have exited func
0x55555076C:	ret	//pc=_________              will not runbecause we have
                                             exited func
*/